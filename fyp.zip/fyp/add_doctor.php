<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_name'])) {
    header("Location: index.php");
    exit();
}

require "db_conn.php";
if (isset($_POST['submit'])) {

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $firstName = $_POST['name'];
  $middleName = $_POST['middleName'];
  $lastName = $_POST['lastName'];
  $bod = $_POST['bod'];
  $phoneNumber = $_POST['phoneNumber'];
  $address1 = $_POST['address1'];
  $address2 = $_POST['address2'];
  $city = $_POST['city'];
  $IC = $_POST['IC'];
  $orgEmail = $_POST['orgEmail'];
  $postcode = $_POST['postcode'];
  $nationality  = $_POST['nationality'];
  $user_name = $_POST['user_name'];
  $specialist = $_POST['Specialist'];
  $password = $_POST['password'];
  $clinic_id = $_POST['clinic_id'];
  
  $query = "INSERT INTO users (name, middleName, lastName, bod, phoneNumber, address1, address2, city, IC, orgEmail, postcode, nationality, user_name, Specialist, password, clinic_id) VALUES ('$firstName', '$middleName', '$lastName', '$bod', '$phoneNumber', '$address1', '$address2', '$city', '$IC', '$orgEmail', '$postcode', '$nationality', '$user_name', '$specialist', '$password', '$clinic_id')";
  
  if (mysqli_query($conn, $query)) {
    echo "Record inserted successfully";
    // Redirect after successful submission to avoid multiple submissions on refresh
    header("Location: admin.php");
    exit();
} else {
    echo "Error: " . mysqli_error($conn);
}
}
}

$query = "SELECT clinic_id, clinicName FROM clinic";
$result = mysqli_query($conn, $query);

// Check if the query was successful
if ($result) {
    // Fetch the data as an associative array
    $clinics = mysqli_fetch_all($result, MYSQLI_ASSOC);

    // Free the result set
    mysqli_free_result($result);
} else {
    // Handle the case where the query failed
    echo "Error: " . mysqli_error($conn);
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <style>
    /* CSS styles */
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 20px;
      background-color: #f2f2f2;
    }

    h1,
    h2 {
      color: #333;
      margin-top: 0;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    th,
    td {
      padding: 10px;
      text-align: left;
    }

    th {
      background-color: #333;
      color: #fff;
    }

    tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    tr:hover {
      background-color: #ddd;
    }

    form {
      margin-bottom: 10px;
    }

    .button {
      padding: 8px 16px;
      background-color: #333;
      color: #fff;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .button:hover {
      background-color: #555;
    }

    label {
      font-weight: bold;
    }

    input[type="text"],
    input[type="number"],
    input[type="password"],
    input[type="date"],
    select {
      width: 100%;
      padding: 8px;
      border-radius: 4px;
      border: 1px solid #ccc;
      margin-bottom: 10px;
    }

    #addMenuButton,
    #submitRestaurantButton {
      display: inline-block;
      margin-right: 10px;
    }

    #addMenuButton {
      margin-top: 10px;
    }

    .navbar-link {
      display: inline-block;
      padding: 10px 16px;
      background-color: #333;
      color: #fff;
      text-decoration: none;
      border-radius: 4px;
    }

    .navbar-link:hover {
      background-color: #555;
    }

    .physicianName label {
        display: inline-block;
        width: auto; /* Adjust the width as needed */
        text-align: right;
        margin-right: 10px; /* Adjust the margin as needed */
    }

    .physicianName input {
        display: inline-block;
        width: 110px; /* Adjust the width as needed */
    }

    .physicianInfo label {
        display: inline-block;
        width: auto; /* Adjust the width as needed */
        text-align: right;
        margin-right: 10px; /* Adjust the margin as needed */
    }

    .physicianInfo input {
        display: inline-block;
        width: 190px; /* Adjust the width as needed */
    }

    .nationalitySelect {
        width: 250px; /* Adjust the width as needed */
    }


  </style>
</head>

<body>
  <div>
    <a href="admin.php" class="navbar-link" data-nav-link>Home</a>
    <a href="logout.php" class="navbar-link" data-nav-link style="float: right;">Log Out</a>
</div> 
  <br>
  <br>
  
  <h2 style="text-align: center;">Add New Physician</h2>
  <form action="" method="post" style="margin: 0 auto; width: 50%;">
        <div id="menuContainer">
        <div class="menu-input">
        <div class = "physicianName">
            <label for="name">First Name:</label>
            <input type="text" name="name" placeholder="First Name" id="name" multiple required>
            <label for="middleName">Middle Name:</label>
            <input type="text" name="middleName" placeholder="Middle Name" id="middleName" multiple required>
            <label for="lastName">Last Name:</label>
            <input type="text" name="lastName" placeholder="Last Name" id="lastName" multiple required>
        </div>   
        <br>
        <div class = "physicianInfo">
        <label for="bod">Birth of Date:</label>
            <input type="date" id="bod" name="bod">
            <label for="phoneNumber">Phone number:</label>
            <input type="text" name="phoneNumber" placeholder="Phone Number" id="phoneNumber" multiple required>
            <br>
            <br>
            <label for="address">Address:</label>
            <input type="text" name="address1" placeholder="Address Line 1" id="address1" multiple required>
            <input type="text" name="address2" placeholder="Address Line 2" id="address2" multiple required>
            <input type="text" name="city" placeholder="City" id="city" multiple required>
            <br>
            <br>
            <label for="postcode">Postcode:</label>
            <input type="number" name="postcode" placeholder="Postcode" id="postcode" multiple required>
            <label for="nationality">Nationality:</label>
            <select class="nationalitySelect" name="nationality" id="nationality" required>
                <option value="">---Select Nationality---</option>
                <option value="Malay">Malay</option>
                <option value="Chinese">Chinese</option>
                <option value="Indian">Indian</option>
                <option value="Other">Other</option>
            </select>
            <br>
            <br>
            <label for="IC">No. IC/Passport:</label>
            <input type="number" name="IC" placeholder="IC Number" id="IC" multiple required>
            <label for="orgEmail">Organization email:</label>
            <input type="text" name="orgEmail" placeholder="Organizational Email" id="orgEmail" multiple required>
            <br>
            <br>
            <label for="user_name">User Name:</label>
            <input type="text" name="user_name" placeholder="Enter a user name" id="user_name" multiple required>
            <label for="Specialist">Specialist:</label>
            <input type="text" name="Specialist" placeholder="Specialist" id="Specialist" multiple required>
            <br>
            <br>
            <select name="clinic_id" id="clinic_id">
                <?php
                // Assuming $clinics is your array containing clinic data
                foreach ($clinics as $clinic) {
                    $optionValue = $clinic['clinic_id'];
                    $optionText = $clinic['clinicName'];
                    echo "<option value=\"$optionValue\">$optionText</option>";
                }
                ?>
            </select>

            <br>
            <br>
            <label for="password">Password:</label>
            <input type="password" name="password" placeholder="Enter a password" id="password" multiple required>
            <label for="confirmPassword">Confirm Password:</label>
            <input type="password" name="confirmPassword" placeholder="Confirm Password" id="confirmPassword" required onkeyup="validate_password()">>
        </div>
        <br>
    </div>
    </div>
    <br>    
    <div style="text-align: center;">
    <button type="submit" id="submitDoctor" name="submit">Submit</button>
    </div>
  </form>
  <script>
        function validate_password() {
 
            var pass = document.getElementById('password').value;
            var confirm_pass = document.getElementById('confirmPassword').value;
            if (pass != confirm_pass) {
                document.getElementById('wrong_pass_alert').style.color = 'red';
                document.getElementById('wrong_pass_alert').innerHTML
                    = '☒ Use same password';
                document.getElementById('create').disabled = true;
                document.getElementById('create').style.opacity = (0.4);
            } else {
                document.getElementById('wrong_pass_alert').style.color = 'green';
                document.getElementById('wrong_pass_alert').innerHTML =
                    '🗹 Password Matched';
                document.getElementById('create').disabled = false;
                document.getElementById('create').style.opacity = (1);
            }
        }
 
        function wrong_pass_alert() {
            if (document.getElementById('password').value != "" &&
                document.getElementById('confirmPassword').value != "") {
                alert("Your response is submitted");
            } else {
                alert("Please fill all the fields");
            }
        }
    </script>
</body>

</html>
<?php
// Exit the script here if the user is logged in
?>
