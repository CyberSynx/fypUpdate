<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_name'])) {
    header("Location: index.php");
    exit();
}


require "db_conn.php";

$query = "SELECT clinic.clinic_id, clinic.clinicName, clinic.clinicAddress, clinic.clinicServices, GROUP_CONCAT(users.name) AS physicians
FROM clinic
LEFT JOIN users ON clinic.clinic_id = users.clinic_id
GROUP BY clinic.clinic_id, clinic.clinicName, clinic.clinicAddress, clinic.clinicServices";

$result = mysqli_query($conn, $query);

if (isset($_POST['remove'])) {
    $userIdToDelete = $_POST['remove'];

    // Perform the deletion operation based on the clinic ID or any unique identifier you use
    $deleteQuery = "DELETE FROM clinic WHERE clinic_id = $userIdToDelete";

    // Execute the query to delete the record
    mysqli_query($conn, $deleteQuery);

    // After deletion, you may want to redirect or refresh the page
    header("Location: admin.php");
    exit();
}

// Handle new clinic submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    $clinicName = $_POST['clinicName'];
    $clinicAddress = $_POST['clinicAddress'];
    $clinicServicesArray = $_POST['clinicServices'];

    $clinicServices = implode(', ', $clinicServicesArray);

    $query = "INSERT INTO clinic (clinicName, clinicAddress, clinicServices) VALUES ('$clinicName', '$clinicAddress', '$clinicServices')";

    if (mysqli_query($conn, $query)) {
        echo "Record inserted successfully";
        // Redirect after successful submission to avoid multiple submissions on refresh
        header("Location: admin.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}


// Check if the query was successful
if ($result) {
    echo "<div>";
    echo "    ";
    echo "    <a href='logout.php' class='navbar-link' data-nav-link style='float: right;'>Log Out</a>";
    echo "</div>";
    echo "<br>";
    echo "<br>";
    echo "<h1 style='text-align: center;'>Admin Only</h1>";
    echo "<h2 style='text-align: center;'>Clinic List</h2>";
    echo "<table>";
    echo "<thead>";
    echo "<tr>";
    echo "<th>Remove</th>";
    echo "<th>Clinic Name</th>";
    echo "<th>Address</th>";
    echo "<th>Services</th>";
    echo "<th>Physicians</th>";
    echo "<th>Action</th>";
    echo "</tr>";
    echo "</thead>";

    echo "<tbody>";
    // Check if there is at least one row in the result set
    if (mysqli_num_rows($result) > 0) {
        // Loop through each row in the result set
        while ($data = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>";
            echo "<form method='POST'>";
            echo "<input type='hidden' name='remove' value='" . $data['clinic_id'] . "'>";
            echo "<button type='submit' class='button' onclick='return confirm(\"Are you sure you want to delete " . $data['clinicName'] . "?\")'>Delete</button>";
            echo "</form>";
            echo "</td>";
            echo "<td>" . $data['clinicName'] . "</td>";
            echo "<td>" . $data['clinicAddress'] . "</td>";
            echo "<td>" . $data['clinicServices'] . "</td>";
            echo "<td>" . $data['physicians'] . "</td>";
            echo "<td>";
            echo "<form id='addPhysician' action='add' method='POST' style='display: inline;'>";
            echo "<a href='add_doctor.php' class='button'>Add</a>";
            echo "</form>";
            echo "  ";
            echo "<form id='editPhysician' action='edit' method='POST' style='display: inline;'>";
            echo "<a href='edit_doctors.php' class='button'>Update/Delete</a>";
            echo "</form>";
            echo "</td>";
            echo "</tr>";
        }
    } else {
        // Handle the case where the query returned no results
        echo "<tr><td colspan='6'>No data available</td></tr>";
    }

    echo "</tbody>";
    echo "</table>";

    // Close the result set
    mysqli_free_result($result);
} else {
    // Handle the case where the query failed
    echo "Error: " . mysqli_error($conn);
}

// Close the database connection
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <style>
    /* CSS styles */
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 20px;
      background-color: #f2f2f2;
    }

    h1,
    h2 {
      color: #333;
      margin-top: 0;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    th,
    td {
      padding: 10px;
      text-align: left;
    }

    th {
      background-color: #333;
      color: #fff;
    }

    tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    tr:hover {
      background-color: #ddd;
    }

    form {
      margin-bottom: 20px;
    }

    .button {
      padding: 8px 16px;
      background-color: #333;
      color: #fff;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .button:hover {
      background-color: #555;
    }

    label {
      font-weight: bold;
    }

    input[type="text"],
    input[type="number"],
    select {
      width: 100%;
      padding: 8px;
      border-radius: 4px;
      border: 1px solid #ccc;
      margin-bottom: 10px;
    }

    #addMenuButton,
    #submitRestaurantButton {
      display: inline-block;
      margin-right: 10px;
    }

    #addMenuButton {
      margin-top: 10px;
    }

    .navbar-link {
      display: inline-block;
      padding: 10px 16px;
      background-color: #333;
      color: #fff;
      text-decoration: none;
      border-radius: 4px;
    }

    .navbar-link:hover {
      background-color: #555;
    }
  </style>
</head>

<body>

  <h2 style="text-align: center;">Add New Clinic</h2>
  <form action="" method="post" style="margin: 0 auto; width: 50%;">
    <div id="menuContainer">
    <div class="menu-input">
        <label for="clinicName">Clinic Name:</label>
        <input type="text" name="clinicName" placeholder="Enter a name" id="clinicName" required>
        <br>
        <label for="clinicAddress">Address:</label>
        <input type="text" name="clinicAddress" placeholder="Enter the Address" id="clinicAddress" required>
         <br>
        <div id="dataRows">
        <!-- Initial row of input fields -->
        <div>
            <label for="clinicServices">Add Services:</label>
            <input type="text" name="clinicServices[]" placeholder="Enter a service" id="clinicServices" required>
        </div>
        </div>
        <br>
    </div>
    </div>
    <br>

    <div style="text-align: center;"> 
    <button type="button" onclick="addRow()">Add</button>
    <button type="submit" id="submitButton" name="submit">Submit</button>
    </div>
    
    <!-- Add a hidden input field to keep track of the javascript counter variable -->
    <!-- <input type="hidden" name="counter" value=0 id="counter"> -->
  </form>

  <script>
        function addRow() {
            // Clone the last row and append it to the container
            var lastRow = document.getElementById("dataRows").lastElementChild;
            var newRow = lastRow.cloneNode(true);
            document.getElementById("dataRows").appendChild(newRow);
        }
    </script>
  

</body>

</html>
<?php
// Exit the script here if the user is logged in
?>
