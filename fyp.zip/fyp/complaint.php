<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html lang = "en">
 <head>
    <meta charset = "utf-8" />
    <meta http-equiv = "X-UA-Compatible" content = "IE = edge" />
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link 
        rel = "stylesheet" 
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" 
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" 
        crossorigin="anonymous" 
        referrerpolicy="no-referrer"
        />
    <link rel = "stylesheet" href = "style2.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital@1&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>

<!-- Popper JS -->
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

</head>

 <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
 <body>
    <header class="first-header">
        <div class="navbar2">
            <div class="logo"><h1>Welcome, <?php echo $_SESSION['name']; ?>!</h1></div>
                <div class="nav-buttons">
                    <div class="logout-container">
                        <button class="logout">Logout</button>
                        <a href="logout.php" class="logout"></a>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div class="sidebar">
        <a href="home.php">Dashboard</a>
        <a class="active" href="complaint.php">Complaint</a>
        <a href="#contact">Patient Record</a>
        <a href="#about">Bills</a>
    </div>
    <br><br>

	<div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2 bg-light p-4 mt-5 rounded">
                <form action="signing.php" method="POST">
                    <div class="form-group">
                        <label for="pat_data">Message: </label>
                        <textarea name="pat_data" class="form-control" id="pat_data" rows="3" placeholder="Enter Message"></textarea>
                    </div>
                    <button type="submit" name="encrypt" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
 
</body>
</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>