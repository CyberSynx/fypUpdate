<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_name']) || !isset($_SESSION['clinic_id']) || !isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$userName = $_SESSION['user_name'];
$clinicID = $_SESSION['clinic_id'];
$userID = $_SESSION['user_id'];
$patientID = $_GET['patient_id'];

require "db_conn.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    $consultationDate = $_POST['consultationDate'];
    $medicationName = $_POST['medicationName'];
    $dosage = $_POST['dosage'];
    $frequency = $_POST['frequency'];
    $startTreatment = $_POST['startTreatment'];
    $endTreatment = $_POST['endTreatment'];
    $user_name = $_POST['user_name'];
    $clinic_id = $_POST['clinic_id'];
    $user_id = $_POST['user_id'];
    $patient_id = $_POST['patient_id'];
    
    $query = "INSERT INTO patient_record (consultationDate, medicationName, dosage, frequency, startTreatment, endTreatment, user_name, clinic_id, user_id, patient_id) VALUES ('$consultationDate', '$medicationName', '$dosage', '$frequency', '$startTreatment', '$endTreatment', '$user_name', '$clinic_id', '$user_id', '$patient_id')";
    
    if (mysqli_query($conn, $query)) {
      echo "Record inserted successfully";
      // Redirect after successful submission to avoid multiple submissions on refresh
      header("Location: home.php");
      exit();
  } else {
      echo "Error: " . mysqli_error($conn);
  }
}

?>

<!DOCTYPE html>
<html lang = "en">
 <head>
    <meta charset = "utf-8" />
    <meta http-equiv = "X-UA-Compatible" content = "IE = edge" />
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Vollkorn+SC:wght@600&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=K2D:wght@500&display=swap" rel="stylesheet">
    <link 
        rel = "stylesheet" 
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" 
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" 
        crossorigin="anonymous" 
        referrerpolicy="no-referrer"
        />
    <link rel = "stylesheet" href = "style.css" />
    <title>Luqman Personal Portfolio</title>
 </head>

 <body class="home-body">
 
    <header class="first-header">
    <div class="navbar2">
    <button class="w3-button w3-teal w3-xlarge w3-left" onclick="openLeftMenu()">&#9776;</button>
        <div class="logo"><a>SihatSiaga</a></div>
            <div class="nav-buttons">
            <button onclick="document.location='logout.php'">Logout</button>
            </div>
            
        </div>
    </div>
    </header>


    <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="leftMenu">
  <button onclick="closeLeftMenu()" class="w3-bar-item w3-button w3-large">Close &times;</button>
  <a href="home.php" class="w3-bar-item w3-button">Dashboard</a>
  <a href="registerPatient.php" class="w3-bar-item w3-button">Register new patient</a>
  <a href="searchPatient.php" class="w3-bar-item w3-button">Search Patient Record</a>
  <a href="patientRecord.php" class="w3-bar-item w3-button">My Patient Record</a>
</div>

<div class="w3-teal">
  <div class="w3-container">
    <h1>Consultation</h1>
  </div>
</div>

<div class="w3-container">
        <h2></h2>
    <div>
        <p>Welcome, <?php echo $userName; ?>!</p>
        <p>Clinic ID: <?php echo $clinicID; ?></p>
        <p>User ID: <?php echo $userID; ?></p>
        <p>Patient ID: <?php echo $patientID; ?></p>
    </div>
        <div class="w3-card-4">
            <div class="w3-container w3-teal">
                <h2>Patient Complaints</h2>
            </div>

            <form class="w3-container custom-form" action="" method="post">
                <br><br>
                <label for="consultationDate">Date:</label>
                <input type="date" id="consultationDate" name="consultationDate" required>

                <label for="medicationName">Medication Name:</label>
                <input type="text" id="medicationName" name="medicationName" required>

                <label for="dosage">Dosage:</label>
                <input type="text" id="dosage" name="dosage" required>

                <label for="frequency">Frequency:</label>
                <input type="number" id="frequency" name="frequency" required>

                <label for="startTreatment">Start treatment:</label>
                <input type="date" id="startTreatment" name="startTreatment" required>

                <label for="endTreatment">End treatment:</label>
                <input type="date" id="endTreatment" name="endTreatment" required>

                <input type="hidden" id="user_name" name="user_name" value="<?php echo $_SESSION['user_name']; ?>">
                <input type="hidden" id="clinic_id" name="clinic_id" value="<?php echo $clinicID = $_SESSION['clinic_id']; ?>">
                <input type="hidden" id="user_id" name="user_id" value="<?php echo $$userID = $_SESSION['user_id']; ?>">
                <input type="hidden" id="patient_id" name="patient_id" value="<?php echo $_GET['patient_id']; ?>">

            
                <button type="submit" id="submitButton" name="submit">Submit</button>
            </form>
        </div>
    </div>





<script>
function openLeftMenu() {
  document.getElementById("leftMenu").style.display = "block";
}

function closeLeftMenu() {
  document.getElementById("leftMenu").style.display = "none";
}

</script>
</script>
 </body>
</html>
<?php
// Exit the script here if the user is logged in
?>
