<a href = "#" class="action_btn">Contact Me</a>
            <div class = "toggle_btn">
                <i class="fa-solid fa-bars"></i>
            </div>
        </div>

        <div class = "dropdown_menu">
            <li><a href = "home">Login</a></li>
            <li><a href = "about">About</a></li>
            <li><a href = "education">education</a></li>
            <li><a href = "skills">skills</a></li>
            <li><a href = "#" class = "action_btn">Contact Me</a></li>
    </header>

    @media (max-width: 992px) {
    .first-header .navbar2 .links,
    .first-header .navbar2 .action_btn{
        display: none;
    }
    .navbar2 .toggle_btn{
        display: block;
        font-size: 3.5vw;
        padding-right: 20px;
    }
    .first-header .logo a {
        padding-left: 40px;
        font-size: 3.0vw; /* Adjust the font size of the logo for improved readability */
    }

    .dropdown_menu{
        display: block;
    }

    .dropdown_menu li a{
        font-size: 1.0rem;
    }

    .dropdown_menu {
        width: 50%; /* Adjust the width as a percentage of the screen width for smaller screens */
    }
}