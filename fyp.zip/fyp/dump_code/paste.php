<?php

// Function to calculate the hash of a block 
function calculateHash($index, $previousHash, $timestamp, $data) {
    //echo "data: " . $data . "<br><br>";
    return hash('sha256', $index . $previousHash . $timestamp . $data);
}

// Function to encrypt the IP address
function IpAddress($ipAddress) {
    // Replace this with your encryption logic for the IP address
    return ($ipAddress); // Example encryption using SHA-256
}

// Caesar Cipher Shift function
function caesarCipherEncrypt($string, $shift) {
    $result = "";
    $length = strlen($string);
    for ($i = 0; $i < $length; $i++) {
        if (ctype_alpha($string[$i])) {
            $isUpperCase = ctype_upper($string[$i]);
            $asciiOffset = $isUpperCase ? 65 : 97;
            $result .= chr(fmod(((ord($string[$i]) + $shift) - $asciiOffset), 26) + $asciiOffset);
        } else {
            $result .= $string[$i];
        }
    }
    return $result;
}

// Function to generate digital signature
function generateDigitalSignature($timestamp, $macAddress, $userInputData, $ipAddress, $securedGatewayHash) {
    return $timestamp . "," . $macAddress . "," . $userInputData . "," . $ipAddress . "," . $securedGatewayHash;
}

class Block {
    public $index;
    public $timestamp;
    public $data;
    public $previousHash;
    public $hash;

    public function __construct($index, $timestamp, $data, $previousHash) {
        $this->index = $index;
        $this->timestamp = $timestamp;
        $this->data = $data;
        $this->previousHash = $previousHash;
        $this->hash = calculateHash($index, $previousHash, $timestamp, $data);
    }
}

// Get MAC address
$macAddress = exec('C:\Windows\System32\getmac');
$pattern = '/([A-Za-z0-9]+(-[A-Za-z0-9]+)+)/';
preg_match_all($pattern, $macAddress, $matches);
$cleanedMacAddress = isset($matches[0][0]) ? $matches[0][0] : 'Not Found';
// Encrypt IP address
$ipAddress = $_SERVER['REMOTE_ADDR'];
$IpAddress = IpAddress($ipAddress);

//what will happen when user press submit button
if (isset($_POST['encrypt'])) {
// Create nonce (Block 0)
$block0 = new Block(0, date("Y-m-d H:i:s"), $cleanedMacAddress, "0");
// Handle user input and create Block 1
$userInputData = $_POST['text'];
$block1 = new Block(1, date("Y-m-d H:i:s"), $userInputData, $block0->hash);
// Simulate IP address encryption (Block 2)
$block2 = new Block(2, date("Y-m-d H:i:s"), $IpAddress, $block1->hash);
// Combine hashes into a single string
$gatewayHashes = $block0->hash . ',' . $block1->hash . ',' . $block2->hash;
// Apply Caesar Cipher Shift encryption to combined hashes
$caesarShiftAmount = 3; // Example shift amount
$securedGatewayHash = caesarCipherEncrypt($gatewayHashes, $caesarShiftAmount);
// Generate digital signature
$digitalSignature = generateDigitalSignature(date("Y-m-d H:i:s"), $block0->data, $block1->data, $block2->data, $securedGatewayHash);
}
//echo "Timestamp: " . $block1->timestamp . "<br><br>";

//echo "Digital Signature: " . $digitalSignature . "<br><br>";

//==================================== Verify digital signature =============================

//$components = explode(",", $digitalSignature);

//$block5 = new Block(0, $components[0], date("Y-m-d H:i:s"), "0");
//$block6 = new Block(1, $components[1], date("Y-m-d H:i:s"), $block5->hash);
//$block7 = new Block(2, $components[2], date("Y-m-d H:i:s"), $block6->hash);

//$serverHashes = "0" . ',' . $block5->hash . ',' . $block6->hash . ',' . $block7->hash;

//$caesarShiftAmount = 3; // Example shift amount
//$securedServerHash = caesarCipherEncrypt($serverHashes, $caesarShiftAmount);
//$securedGatewayHash = $components[3] . "," . $components[4] . "," . $components[5] . "," . $components[6] . "23";

// Display blocks, combined hashes, secured gateway hash, and digital signature
//echo "Block 0 - Index: " . $block0->index . " Hash: " . $block0->hash . "Timestamp: " . $block0->timestamp . "<br> Data (MAC Address): " . $block0->data . "<br><br>";
//echo "Block 1 - Index: " . $block1->index . " Hash: " . $block1->hash . "Timestamp: " . $block1->timestamp . " <br> Data (User Input): " . $block1->data . "<br><br>";
//echo "Block 2 - Index: " . $block2->index . " Hash: " . $block2->hash . "Timestamp: " . $block2->timestamp . " <br> Data (IP Address): " . $block2->data . "<br><br>";
//echo "Gateway Hashes: " . $gatewayHashes . "<br><br>";
//echo "Secured Gateway Hash: " . $securedGatewayHash . "<br><br>";
//echo "<br><br>";
//echo "==================================== Verify digital signature =============================<br><br>";
//echo "components: " . $components[0] . "<br>";
//echo "components: " . $components[1] . "<br>";
//echo "components: " . $components[2] . "<br>";
//echo "components: " . $components[3] . "<br>";
//echo "components: " . $components[4] . "<br>";
//echo "components: " . $components[5] . "<br>";
//echo "components: " . $components[6] . "<br>";
//echo "<br><br>";
//echo "securedServerHash: " . $securedServerHash .  "<br><br>";
//echo "<br><br>";
//echo "secureGatewaydHash: " . $securedGatewayHash . "<br><br>";

//if ($securedGatewayHash == $securedServerHash) {
//    echo "Digital signature is valid";
//} else {
//    echo "Digital signature is invalid";
//}
//echo "<br><br>";


?> 

<?php
//============================================ SIGNING.PHP ============================================

function calculateHash($index, $previousHash, $timestamp, $data) {
    return hash('sha256', $index . $previousHash . $timestamp . $data);
}

function IpAddress($ipAddress) {
    return ($ipAddress);
}

function caesarCipherEncrypt($string, $shift) {
    $result = "";
    $length = strlen($string);
    for ($i = 0; $i < $length; $i++) {
        if (ctype_alpha($string[$i])) {
            $isUpperCase = ctype_upper($string[$i]);
            $asciiOffset = $isUpperCase ? 65 : 97;
            $result .= chr(fmod(((ord($string[$i]) + $shift) - $asciiOffset), 26) + $asciiOffset);
        } else {
            $result .= $string[$i];
        }
    }
    return $result;
}

function generateDigitalSignature($timestamp, $macAddress, $userInputData, $ipAddress, $securedGatewayHash) {
    return $timestamp . "," . $macAddress . "," . $userInputData . "," . $ipAddress . "," . $securedGatewayHash;
}

class Block {
    public $index;
    public $timestamp;
    public $data;
    public $previousHash;
    public $hash;

    public function __construct($index, $timestamp, $data, $previousHash) {
        $this->index = $index;
        $this->timestamp = $timestamp;
        $this->data = $data;
        $this->previousHash = $previousHash;
        $this->hash = calculateHash($index, $previousHash, $timestamp, $data);
    }
}

$macAddress = exec('C:\Windows\System32\getmac');
$pattern = '/([A-Za-z0-9]+(-[A-Za-z0-9]+)+)/';
preg_match_all($pattern, $macAddress, $matches);
$cleanedMacAddress = isset($matches[0][0]) ? $matches[0][0] : 'Not Found';

$ipAddress = $_SERVER['REMOTE_ADDR'];
$IpAddress = IpAddress($ipAddress);


if (isset($_POST['encrypt'])) {

    $block0 = new Block(0, date("Y-m-d H:i:s"), $cleanedMacAddress, "0");
    $userInputData = $_POST['text'];
    $block1 = new Block(1, date("Y-m-d H:i:s"), $userInputData, $block0->hash);
    $block2 = new Block(2, date("Y-m-d H:i:s"), $IpAddress, $block1->hash);
    $gatewayHashes = $block0->hash . ',' . $block1->hash . ',' . $block2->hash;
    $caesarShiftAmount = 3; // Example shift amount
    $securedGatewayHash = caesarCipherEncrypt($gatewayHashes, $caesarShiftAmount);
    $digitalSignature = generateDigitalSignature(date("Y-m-d H:i:s"), $block0->data, $block1->data, $block2->data, $securedGatewayHash);
}   
?>