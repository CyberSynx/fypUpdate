<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_name']) || !isset($_SESSION['clinic_id']) || !isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$userName = $_SESSION['user_name'];
$clinicID = $_SESSION['clinic_id'];
$userID = $_SESSION['user_id'];

require "db_conn.php";

// Get clinicID, clinicName, physicianName, and count of patients in a single query
$queryClinic = "SELECT c.clinic_id, c.clinicName, u.name AS physicianName,
                       (SELECT COUNT(patient_id) FROM registered_patient WHERE clinic_id = c.clinic_id) AS totalPatient,
                       (SELECT COUNT(clinic_id) FROM clinic) AS totalClinics,
                       (SELECT COUNT(user_id) FROM users WHERE clinic_id = c.clinic_id) AS totalPhysicians,
                       (SELECT COUNT(*) FROM patient_record WHERE consultationDate = CURDATE() AND clinic_id = c.clinic_id) AS countResult,
                       CURDATE() AS currentDate
                FROM clinic c
                JOIN users u ON c.clinic_id = u.clinic_id
                WHERE c.clinic_id = ? AND u.user_id = ?";
$stmtClinic = mysqli_prepare($conn, $queryClinic);
mysqli_stmt_bind_param($stmtClinic, "ii", $clinicID, $userID);
mysqli_stmt_execute($stmtClinic);
mysqli_stmt_bind_result($stmtClinic, $clinicID, $clinicName, $physicianName, $totalPatient, $totalClinics, $totalPhysicians, $countResult, $currentDate);

if (mysqli_stmt_fetch($stmtClinic)) {
    

    // Close the first statement before preparing the next one
    mysqli_stmt_close($stmtClinic);

    // Query to count total patients in registered_patient table for the current clinic
    $queryCountPatients = "SELECT COUNT(patient_id) AS totalPatients
                       FROM registered_patient";
$stmtCountPatients = mysqli_prepare($conn, $queryCountPatients);
mysqli_stmt_execute($stmtCountPatients);
mysqli_stmt_bind_result($stmtCountPatients, $totalPatients);

if (mysqli_stmt_fetch($stmtCountPatients)) {
    
} else {
    echo "Error fetching total patient count.";
}

    mysqli_stmt_close($stmtCountPatients);
} else {
    echo "Error fetching clinic data.";
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang = "en">
 <head>
    <meta charset = "utf-8" />
    <meta http-equiv = "X-UA-Compatible" content = "IE = edge" />
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Vollkorn+SC:wght@600&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=K2D:wght@500&display=swap" rel="stylesheet">
    <link 
        rel = "stylesheet" 
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" 
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" 
        crossorigin="anonymous" 
        referrerpolicy="no-referrer"
        />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel = "stylesheet" href = "style.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Luqman Personal Portfolio</title>

    <style>
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {
      display: flex;
      justify-content: center; /* Horizontal centering */
      height: 100vh; /* 100% of the viewport height */
    }
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
    }
        
    /* On small screens, set height to 'auto' for the grid */
    @media screen and (max-width: 767px) {
      .row.content {height: auto;} 
    }
  </style>
 </head>

 <body class="home-body">
 
    <header class="first-header">
    <div class="navbar2">
    <button class="w3-button w3-teal w3-xlarge w3-left" onclick="openLeftMenu()">&#9776;</button>
        <div class="logo"><a>SihatSiaga</a></div>
            <div class="nav-buttons">
            <button onclick="document.location='logout.php'">Logout</button>
            </div>
            
        </div>
    </div>
    </header>


    <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="leftMenu">
  <button onclick="closeLeftMenu()" class="w3-bar-item w3-button w3-large">Close &times;</button>
  <a href="home.php" class="w3-bar-item w3-button">Dashboard</a>
  <a href="registerPatient.php" class="w3-bar-item w3-button">Register new patient</a>
  <a href="searchPatient.php" class="w3-bar-item w3-button">Search Patient Record</a>
  <a href="patientRecord.php" class="w3-bar-item w3-button">My Patient Record</a>
</div>

<div class="w3-teal">
  <div class="w3-container">
    <h1>Dashboard</h1>
  </div>
</div>

<br>
<br>
<br>

<div class="container-fluid">
  <div class="row content">
    <br>
    
    <div class="col-sm-9">
      <div class="well">
      <h1>Welcome to <?php echo $clinicName; ?></h1>
        <h3>Nice to meet you <?php echo $physicianName; ?>!</h3>
      </div>
      <div class="row">
        <div class="col-sm-3">
          <div class="well">
            <h3>Total clinics:</h3>
            <h2><?php echo $totalClinics?></h2> 
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well">
            <h3>Physicians in clinic:</h3>
            <h2><?php echo $totalPhysicians?></h2> 
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well">
            <h3>Total patients:</h3>
            <h2><?php echo $totalPatients?></h2> 
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well">
            <h3>Registered patients:</h3>
            <h2><?php echo $totalPatient?></h2> 
          </div>
        </div>
      </div>
      <div class="row">
      <div class="col-sm-9">
          <div class="well">
          <h3>Total patient today:</h3>
          <h2><?php echo $countResult?></h2> 
          </div>
      </div>
      <div class="col-sm-3">
          <div class="well">
            <h3>Date:</h3>
            <h2><?php echo $currentDate?></h2> 
          </div>
        </div>
        </div>
        </div>
      </div>
    </div>
  </div>
</div>




<script>
function openLeftMenu() {
  document.getElementById("leftMenu").style.display = "block";
}

function closeLeftMenu() {
  document.getElementById("leftMenu").style.display = "none";
}


</script>
</script>
 </body>
</html>