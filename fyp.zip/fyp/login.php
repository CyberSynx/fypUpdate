<?php 
session_start(); 
include "db_conn.php";

if (isset($_POST['user_name']) && isset($_POST['password'])){

    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $uname = validate($_POST['user_name']);
    $pass = validate($_POST['password']);

    if (empty($uname)){
        header("Location: index.php?error=User Name is required");
        exit();
    } else if (empty($pass)){
        header("Location: index.php?error=Password is required");
        exit();
    } else if ($uname == 'admin'){
        $sql = "SELECT * FROM users WHERE user_name='admin' AND password='$pass'"; // Database column for username is user_name and password is password
        
        $result = mysqli_query($conn, $sql);

        if ($result) {
            $row = mysqli_fetch_assoc($result);

            if ($row && $row['user_name'] === 'admin' && $row['password'] === $pass) {
                $_SESSION['user_name'] = $row['user_name'];
                $_SESSION['name'] = $row['name'];
                $_SESSION['id'] = $row['id'];
                header("Location: admin.php");
                exit();
            } else {
                header("Location: index.php");
                exit();
            }
        }
    } else {
        // Non-admin users
        $sql = "SELECT * FROM users WHERE NOT user_name='admin' AND password='$pass'";            
        $result = mysqli_query($conn, $sql);

        if ($result) {
            $row = mysqli_fetch_assoc($result);

            if ($row && $row['user_name'] === $uname && $row['password'] === $pass) {
                $_SESSION['user_name'] = $row['user_name'];
                $_SESSION['clinic_id'] = $row['clinic_id'];
                $_SESSION['user_id'] = $row['user_id'];
                header("Location: home.php");
                exit();
            } else {
                header("Location: index.php");
                exit();
            }
        }
    }
} else {
    header("Location: index.php");
    exit();
}
?>
