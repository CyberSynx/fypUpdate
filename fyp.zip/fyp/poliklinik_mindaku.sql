-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2023 at 08:38 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `poliklinik_mindaku`
--

-- --------------------------------------------------------

--
-- Table structure for table `clinic`
--

CREATE TABLE `clinic` (
  `clinic_id` int(11) NOT NULL,
  `clinicName` varchar(255) DEFAULT NULL,
  `clinicAddress` varchar(255) DEFAULT NULL,
  `clinicServices` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clinic`
--

INSERT INTO `clinic` (`clinic_id`, `clinicName`, `clinicAddress`, `clinicServices`) VALUES
(2, 'Poliklinik Mindaku', 'Shah alam', 'Denggi'),
(3, 'Klinik Sihat', 'arau', 'lapew'),
(4, 'Klinik Sihat', 'Shah alam', 'Periksa Kesihatan'),
(5, 'Poliklinik Mindaku2', 'Puncak Alam', 'Denggi, Urut badan');

-- --------------------------------------------------------

--
-- Table structure for table `patient_data`
--

CREATE TABLE `patient_data` (
  `pat_data` varchar(255) DEFAULT NULL,
  `birthdate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_data`
--

INSERT INTO `patient_data` (`pat_data`, `birthdate`) VALUES
('FGFDG', ''),
('dsfdsf', ''),
('dsfdsf', '');

-- --------------------------------------------------------

--
-- Table structure for table `patient_record`
--

CREATE TABLE `patient_record` (
  `consultationDate` varchar(255) NOT NULL,
  `medicationName` varchar(255) NOT NULL,
  `dosage` varchar(255) NOT NULL,
  `frequency` int(11) NOT NULL,
  `startTreatment` varchar(255) NOT NULL,
  `endTreatment` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `clinic_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `record_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_record`
--

INSERT INTO `patient_record` (`consultationDate`, `medicationName`, `dosage`, `frequency`, `startTreatment`, `endTreatment`, `user_name`, `clinic_id`, `user_id`, `patient_id`, `record_id`) VALUES
('2023-12-23', 'Ubat Gatal', '500mg', 4, '2023-12-21', '2023-12-30', '_hkiem', 2, 4, 3, 7),
('2023-12-19', 'Paracetamol', '500mg', 2, '2023-12-19', '2023-12-22', '_hkiem', 2, 4, 3, 8),
('2023-12-19', 'Ubat Sakit Kepala', '500mg', 5, '2023-12-19', '2023-12-23', 'hani00135', 3, 5, 3, 9);

-- --------------------------------------------------------

--
-- Table structure for table `registered_patient`
--

CREATE TABLE `registered_patient` (
  `registerDate` varchar(255) NOT NULL,
  `ICnumber` varchar(255) NOT NULL,
  `fullName` varchar(255) NOT NULL,
  `birthdate` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `phoneNumber` varchar(255) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `clinic_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registered_patient`
--

INSERT INTO `registered_patient` (`registerDate`, `ICnumber`, `fullName`, `birthdate`, `address`, `gender`, `phoneNumber`, `patient_id`, `clinic_id`) VALUES
('2023-12-26', '42342342768953', 'liq', '2023-12-09', 'NO.23 JALAN BESAR, TAMAN KAJANG BARU', 'male', '03424    ', 2, 2),
('2023-12-02', '875678', 'erw', '2023-12-30', 'NO.23 JALAN BESAR, TAMAN KAJANG BARU', 'male', '4234324234324', 3, 3),
('2023-12-16', '875678433243543543645', 'erw4rer', '2023-12-07', 'NO.23 JALAN BESAR, TAMAN KAJANG BARU', 'male', '03424    ', 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `middleName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `bod` varchar(255) NOT NULL,
  `phoneNumber` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `postcode` int(255) NOT NULL,
  `nationality` varchar(255) NOT NULL,
  `IC` int(255) NOT NULL,
  `orgEmail` varchar(255) NOT NULL,
  `Specialist` varchar(255) NOT NULL,
  `clinic_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `password`, `name`, `middleName`, `lastName`, `bod`, `phoneNumber`, `address1`, `address2`, `city`, `postcode`, `nationality`, `IC`, `orgEmail`, `Specialist`, `clinic_id`) VALUES
(1, 'admin', '@dmin00123', 'Admin', '', '', '', '', '', '', '', 0, '', 0, '', '', 0),
(4, '_hkiem', '00123', 'Lulu', 'lusd', 'KAMAL', '2023-12-12', '03424', 'NO.23 JALAN BESAR, TAMAN KAJANG BARU', 'JALAN SUNGAI JELOK', 'KAJANG', 43000, 'Malay', 531008081, 'hani@sihatsiaga.com', 'doctor', 2),
(5, 'hani00135', 'hani@00123', 'Rohani', 'lusd', 'KAMAL', '', '03424    ', 'NO.23 JALAN BESAR, TAMAN KAJANG BARU', 'JALAN SUNGAI JELOK', 'KAJANG', 43000, 'Malay', 531008081, 'hani@sihatsiaga.com', 'doctor', 3),
(6, 'Osman00123', 'osman@00123', 'Osman', 'Nul', 'KAMAL', '2023-12-15', '01233456789', 'NO.23 JALAN BESAR, TAMAN KAJANG BARU', 'JALAN SUNGAI JELOK', 'KAJANG', 43000, 'Malay', 531008081, 'Osman@sihatsiaga@gmail.com', 'doctor', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clinic`
--
ALTER TABLE `clinic`
  ADD PRIMARY KEY (`clinic_id`);

--
-- Indexes for table `patient_record`
--
ALTER TABLE `patient_record`
  ADD PRIMARY KEY (`record_id`);

--
-- Indexes for table `registered_patient`
--
ALTER TABLE `registered_patient`
  ADD PRIMARY KEY (`patient_id`),
  ADD UNIQUE KEY `ICnumber` (`ICnumber`),
  ADD KEY `clinic_id` (`clinic_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `clinic_id` (`clinic_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clinic`
--
ALTER TABLE `clinic`
  MODIFY `clinic_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `patient_record`
--
ALTER TABLE `patient_record`
  MODIFY `record_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `registered_patient`
--
ALTER TABLE `registered_patient`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `registered_patient`
--
ALTER TABLE `registered_patient`
  ADD CONSTRAINT `registered_patient_ibfk_1` FOREIGN KEY (`clinic_id`) REFERENCES `clinic` (`clinic_id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`clinic_id`) REFERENCES `clinic` (`clinic_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
