<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_name']) || !isset($_SESSION['clinic_id']) || !isset($_SESSION['user_id'])) {
  header("Location: index.php");
  exit();
}

$userName = $_SESSION['user_name'];
$clinicID = $_SESSION['clinic_id'];
$userID = $_SESSION['user_id'];
require "db_conn.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    $registerDate = $_POST['registerDate'];
    $ICnumber = $_POST['ICnumber'];
    $fullName = $_POST['fullName'];
    $birthdate = $_POST['birthdate'];
    $address = $_POST['address'];
    $gender = $_POST['gender'];
    $phoneNumber = $_POST['phoneNumber'];
    $clinicID = $_SESSION['clinic_id'];
    
    // Use prepared statement to prevent SQL injection
    $query = "INSERT INTO registered_patient (registerDate, ICnumber, fullName, birthdate, address, gender, phoneNumber, clinic_id) VALUES ('$registerDate', '$ICnumber', '$fullName', '$birthdate', '$address', '$gender', '$phoneNumber', '$clinicID')";
    
    if (mysqli_query($conn, $query)) {
      echo "Record inserted successfully";
      // Redirect after successful submission to avoid multiple submissions on refresh
      header("Location: home.php");
      exit();
  } else {
      echo "Error: " . mysqli_error($conn);
  }
}

?>

<!DOCTYPE html>
<html lang = "en">
 <head>
    <meta charset = "utf-8" />
    <meta http-equiv = "X-UA-Compatible" content = "IE = edge" />
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Vollkorn+SC:wght@600&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=K2D:wght@500&display=swap" rel="stylesheet">
    <link 
        rel = "stylesheet" 
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" 
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" 
        crossorigin="anonymous" 
        referrerpolicy="no-referrer"
        />
    <link rel = "stylesheet" href = "style.css" />
    <title>Luqman Personal Portfolio</title>
 </head>

 <body class="home-body">
 
    <header class="first-header">
    <div class="navbar2">
    <button class="w3-button w3-teal w3-xlarge w3-left" onclick="openLeftMenu()">&#9776;</button>
        <div class="logo"><a>SihatSiaga</a></div>
            <div class="nav-buttons">
            <button onclick="document.location='logout.php'">Logout</button>
            </div>
            
        </div>
    </div>
    </header>


    <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="leftMenu">
  <button onclick="closeLeftMenu()" class="w3-bar-item w3-button w3-large">Close &times;</button>
  <a href="home.php" class="w3-bar-item w3-button">Dashboard</a>
  <a href="registerPatient.php" class="w3-bar-item w3-button">Register new patient</a>
  <a href="searchPatient.php" class="w3-bar-item w3-button">Search Patient Record</a>
  <a href="patientRecord.php" class="w3-bar-item w3-button">My Patient Record</a>
</div>

<div class="w3-teal">
  <div class="w3-container">
    <h1>Register patient</h1>
  </div>
</div>
<div>
    <p>Welcome, <?php echo $userName; ?>!</p>
    <p>Clinic ID: <?php echo $clinicID; ?></p>
    <p>User ID: <?php echo $userID; ?></p>
</div>

<div class="w3-container">
        <h2></h2>

        <div class="w3-card-4">
            <div class="w3-container w3-teal">
                <h2>Patient Information</h2>
            </div>

            <form class="w3-container custom-form" action="" method="post">
                <br><br>
                <!-- Your form elements go here -->
                <label for="registerDate">Date:</label>
                <input type="date" id="registerDate" name="registerDate" required>

                <label for="ICnumber">IC Number:</label>
                <input type="text" id="ICnumber" name="ICnumber" required>

                <label for="fullName">Full Name:</label>
                <input type="text" id="fullName" name="fullName" required>

                <label for="birthdate">Birthdate:</label>
                <input type="date" id="birthdate" name="birthdate" required>

                <label for="address">Address:</label>
                <input type="text" id="address" name="address" required>

                <label for="gender">Gender:</label>
                <select name="gender" id="gender">
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                </select>

                <label for="phoneNumber">Phone Number:</label>
                <input type="text" id="phoneNumber" name="phoneNumber" required>

                <input type="hidden" id="clinicID" name="clinicID" value="<?php echo $clinicID; ?>" readonly>

            
                <button type="submit" id="submitButton" name="submit">Submit</button>
            </form>
        </div>
    </div>





<script>
function openLeftMenu() {
  document.getElementById("leftMenu").style.display = "block";
}

function closeLeftMenu() {
  document.getElementById("leftMenu").style.display = "none";
}

</script>
</script>
 </body>
</html>
<?php
// Exit the script here if the user is logged in
?>
