<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_name']) || !isset($_SESSION['clinic_id']) || !isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$userName = $_SESSION['user_name'];
$clinicID = $_SESSION['clinic_id'];
$userID = $_SESSION['user_id'];

require "db_conn.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ICnumber'])) {
    $ICnumber = $_POST['ICnumber'];

    // Query to fetch data from 'registered_patient'
    $sqlRegisteredPatient = "SELECT * FROM registered_patient WHERE ICnumber='$ICnumber'";
    $resultRegisteredPatient = mysqli_query($conn, $sqlRegisteredPatient);

    // Query to fetch data from 'patient_record'
    $sqlPatientRecord = "SELECT rp.*, pr.*, clinic.clinicName, users.name
    FROM registered_patient AS rp
    JOIN patient_record AS pr ON rp.patient_id = pr.patient_id
    JOIN clinic ON clinic.clinic_id = pr.clinic_id
    JOIN users ON users.user_id = pr.user_id
    WHERE rp.ICnumber = '$ICnumber';";
    $resultPatientRecord = mysqli_query($conn, $sqlPatientRecord);

    if ($resultRegisteredPatient->num_rows > 0) {
        echo "<table id='myTable'>";
        echo "<tr class='header'>";
        echo "<th style='width:10%;'>IC Number</th>";
        echo "<th style='width:50%;'>Name</th>";
        echo "<th style='width:40%;'>Action</th>";
        echo "</tr>";

        while ($row = $resultRegisteredPatient->fetch_assoc()) {
            $patient_id = $row['patient_id'];
            echo "<tr>";
            echo "<td>".$row['ICnumber']."</td>";
            echo "<td>".$row['fullName']."</td>";
            echo "<td><button onclick=\"openConsultationForm('$patient_id')\">Consult this patient</button></td>";
            echo "</tr>";
        }
        echo "</table>";
        echo "<br>";
        echo "<h2>Patient Medical History</h2>";

    } else {
        echo "0 results";
    }

    if ($resultPatientRecord->num_rows > 0) {
        echo "<table id='myTable'>";
        echo "<tr class='header'>";
        echo "<th style='width:20%;'>Medication Name</th>";
        echo "<th style='width:20%;'>Dosage</th>";
        echo "<th style='width:20%;'>Freq.</th>";
        echo "<th style='width:40%;'>Physician</th>";
        echo "<th style='width:20%;'>Clinic</th>";
        echo "<th style='width:20%;'>Start</th>";
        echo "<th style='width:20%;'>End</th>";
        echo "</tr>";

        while ($row = $resultPatientRecord->fetch_assoc()) {
            $patient_id = $row['patient_id'];
            echo "<tr>";
            echo "<td>".$row['medicationName']."</td>";
            echo "<td>".$row['dosage']."</td>";
            echo "<td>".$row['frequency']."</td>";
            echo "<td>".$row['name']."</td>";
            echo "<td>".$row['clinicName']."</td>";
            echo "<td>".$row['startTreatment']."</td>";
            echo "<td>".$row['endTreatment']."</td>";
            echo "</tr>";
        }
        echo "</table>";
        echo "<br>";

    } else {
        echo "0 results";
    }

    $conn->close();
    exit(); // Exit to prevent HTML code execution
}

?>


<!DOCTYPE html>
<html lang = "en">
 <head>
    <meta charset = "utf-8" />
    <meta http-equiv = "X-UA-Compatible" content = "IE = edge" />
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Vollkorn+SC:wght@600&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=K2D:wght@500&display=swap" rel="stylesheet">
    <link 
        rel = "stylesheet" 
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" 
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" 
        crossorigin="anonymous" 
        referrerpolicy="no-referrer"
        />
    <link rel = "stylesheet" href = "style.css" />
    <title>Luqman Personal Portfolio</title>

    <style>
* {
  box-sizing: border-box;
}

#searchInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 70%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin: 0 auto; /* Add this line to center the search bar horizontally */
  display: block; /* Ensure it's a block-level element for margin auto to work */
  margin-bottom: 12px;
}


#myTable {
  border-collapse: collapse;
  width: 80%;
  border: 1px solid #ddd;
  font-size: 18px;
  margin: 0 auto; /* Add this line to center the search bar horizontally */
  display: block; /* Ensure it's a block-level element for margin auto to work */
  
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}

#searchButton {
    display: block;
    margin: 0 auto;
}

h2 {
    text-align: center;
}

.input-group {
    position: relative;
}

.input-group i {
    position: absolute;
    left: 250px; /* Adjust the left position as needed */
    top: 50%;
    transform: translateY(-50%);
}
</style>
</head>

 <body class="home-body">
 
    <header class="first-header">
    <div class="navbar2">
    <button class="w3-button w3-teal w3-xlarge w3-left" onclick="openLeftMenu()">&#9776;</button>
        <div class="logo"><a>SihatSiaga</a></div>
            <div class="nav-buttons">
            <button onclick="document.location='logout.php'">Logout</button>
            </div>
            
        </div>
    </div>
    </header>


    <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="leftMenu">
  <button onclick="closeLeftMenu()" class="w3-bar-item w3-button w3-large">Close &times;</button>
  <a href="home.php" class="w3-bar-item w3-button">Dashboard</a>
  <a href="registerPatient.php" class="w3-bar-item w3-button">Register new patient</a>
  <a href="searchPatient.php" class="w3-bar-item w3-button">Search Patient Record</a>
  <a href="patientRecord.php" class="w3-bar-item w3-button">My Patient Record</a>
</div>

<div class="w3-teal">
  <div class="w3-container">
    <h1>Search Patient</h1>
  </div>
</div>
<br>

<div>
    <p>Welcome, <?php echo $userName; ?>!</p>
    <p>Clinic ID: <?php echo $clinicID; ?></p>
    <p>User ID: <?php echo $userID; ?></p>
</div>


<div class="input-group">
    <i class="fa fa-search"></i>
    <input type="text" id="searchInput" placeholder="Enter the IC Number">
</div>
<button id="searchButton" onclick="search()">Search</button>
<br>
    <div id="resultTable"></div>
    <br>
    <div id="recordTable"></div>

<script>
function search() {
    var icNumber = document.getElementById('searchInput').value;

    // Make an AJAX request to your server
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // Update the resultTable with the response from the server
            document.getElementById('resultTable').innerHTML = xhr.responseText;

            // You can also update the recordTable here
            updateRecordTable(icNumber);
        }
    };
    xhr.open('POST', 'searchPatient.php', true);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send('ICnumber=' + icNumber);
}

function updateRecordTable(icNumber) {
    // Make another AJAX request to fetch data for the recordTable
    var recordXhr = new XMLHttpRequest();
    recordXhr.onreadystatechange = function() {
        if (recordXhr.readyState == 4 && recordXhr.status == 200) {
            // Update the recordTable with the response from the server
            document.getElementById('recordTable').innerHTML = recordXhr.responseText;
        }
    };
    recordXhr.open('POST', 'fetchRecord.php', true); // Assuming you have a PHP file to fetch record data
    recordXhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    recordXhr.send('ICnumber=' + icNumber);
}
</script>

<script>
function openLeftMenu() {
  document.getElementById("leftMenu").style.display = "block";
}

function closeLeftMenu() {
  document.getElementById("leftMenu").style.display = "none";
}

</script>

<script>
function openConsultationForm(patientID) {
    // Assuming consultation.php is the form and you want to pass the patientID as a query parameter
    var url = 'consultation.php?patient_id=' + patientID;
    
    // Open the consultation form in a new window or tab
    window.open(url, '_self');
}
</script>
 </body>
</html>
<?php
// Exit the script here if the user is logged in
?>
