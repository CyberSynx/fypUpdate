<?php

function calculateHash($index, $previousHash, $timestamp, $data) {
    return hash('sha256', $index . $previousHash . $timestamp . $data);
}

function IpAddress($ipAddress) {
    return ($ipAddress);
}

function caesarCipherEncrypt($string, $shift) {
    $result = "";
    $length = strlen($string);
    for ($i = 0; $i < $length; $i++) {
        if (ctype_alpha($string[$i])) {
            $isUpperCase = ctype_upper($string[$i]);
            $asciiOffset = $isUpperCase ? 65 : 97;
            $result .= chr(fmod(((ord($string[$i]) + $shift) - $asciiOffset), 26) + $asciiOffset);
        } else {
            $result .= $string[$i];
        }
    }
    return $result;
}

function generateDigitalSignature($timestamp, $macAddress, $userInputData, $ipAddress, $securedGatewayHash) {
    return $timestamp . "," . $macAddress . "," . $userInputData . "," . $ipAddress . "," . $securedGatewayHash;
}

class Block {
    public $index;
    public $timestamp;
    public $data;
    public $previousHash;
    public $hash;

    public function __construct($index, $timestamp, $data, $previousHash) {
        $this->index = $index;
        $this->timestamp = $timestamp;
        $this->data = $data;
        $this->previousHash = $previousHash;
        $this->hash = calculateHash($index, $previousHash, $timestamp, $data);
    }
}

$macAddress = exec('C:\Windows\System32\getmac');
$pattern = '/([A-Za-z0-9]+(-[A-Za-z0-9]+)+)/';
preg_match_all($pattern, $macAddress, $matches);
$cleanedMacAddress = isset($matches[0][0]) ? $matches[0][0] : 'Not Found';

$ipAddress = $_SERVER['REMOTE_ADDR'];
$IpAddress = IpAddress($ipAddress);


if (isset($_POST['encrypt'])) {

    $block0 = new Block(0, date("Y-m-d H:i:s"), $cleanedMacAddress, "0");
    $userInputData = $_POST['pat_data'];
    $block1 = new Block(1, date("Y-m-d H:i:s"), $userInputData, $block0->hash);
    $block2 = new Block(2, date("Y-m-d H:i:s"), $IpAddress, $block1->hash);
    $gatewayHashes = $block0->hash . ',' . $block1->hash . ',' . $block2->hash;
    $caesarShiftAmount = 3; // Example shift amount
    $securedGatewayHash = caesarCipherEncrypt($gatewayHashes, $caesarShiftAmount);
    $digitalSignature = generateDigitalSignature(date("Y-m-d H:i:s"), $block0->data, $block1->data, $block2->data, $securedGatewayHash);
    header("Location: verification.php?digitalSignature=" . urlencode($digitalSignature));
    exit;
}

?> 