<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_name'])) {
    header("Location: index.php");
    exit();
}



require "db_conn.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    $clinicName = $_POST['clinicName'];
    $clinicAddress = $_POST['clinicAddress'];
    $clinicServicesArray = $_POST['clinicServices'];


  $clinicServices = implode(', ', $clinicServicesArray);
  
  $query = "UPDATE clinic SET clinicName = '$clinicName', clinicAddress = '$clinicAddress', clinicServices = '$clinicServices' WHERE clinic_id = $_POST[update_id]";
  
  if (mysqli_query($conn, $query)) {
    echo "Record updated successfully";
    // Redirect after successful submission to avoid multiple submissions on refresh
    header("Location: admin.php");
    exit();
} else {
    echo "Error: " . mysqli_error($conn);
}
}

$query = "SELECT clinic_id, clinicName, clinicAddress, clinicServices FROM clinic";
$result = mysqli_query($conn, $query);

// Check if the query was successful
if ($result) {
    // Fetch the data as an associative array
    $clinics = mysqli_fetch_all($result, MYSQLI_ASSOC);
    mysqli_free_result($result);
} else {
    // Handle the case where the query failed
    echo "Error: " . mysqli_error($conn);
}

// Close the database connection
mysqli_close($conn);
?>

<script>
    function addRow() {
        // Clone the last row and append it to the container
        var lastRow = document.getElementById("dataRows").lastElementChild;
        var newRow = lastRow.cloneNode(true);
        document.getElementById("dataRows").appendChild(newRow);
    }

    function removeRow() {
        // Get all checkboxes
        var checkboxes = document.querySelectorAll('input[name="serviceCheckbox"]:checked');

        // Get the row to be removed
        checkboxes.forEach(function (checkbox) {
            var rowToRemove = checkbox.parentNode;
            // Remove the row
            rowToRemove.parentNode.removeChild(rowToRemove);
        });
    }

</script>

<!DOCTYPE html>
<html lang="en">

<head>
  <style>
    /* CSS styles */
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 20px;
      background-color: #f2f2f2;
    }

    h1,
    h2 {
      color: #333;
      margin-top: 0;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    th,
    td {
      padding: 10px;
      text-align: left;
    }

    th {
      background-color: #333;
      color: #fff;
    }

    tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    tr:hover {
      background-color: #ddd;
    }

    form {
      margin-bottom: 20px;
    }

    .button {
      padding: 8px 16px;
      background-color: #333;
      color: #fff;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .button:hover {
      background-color: #555;
    }

    label {
      font-weight: bold;
    }

    input[type="text"],
    input[type="number"],
    select {
      width: 100%;
      padding: 8px;
      border-radius: 4px;
      border: 1px solid #ccc;
      margin-bottom: 10px;
    }

    #addMenuButton,
    #submitRestaurantButton {
      display: inline-block;
      margin-right: 10px;
    }

    #addMenuButton {
      margin-top: 10px;
    }

    .navbar-link {
      display: inline-block;
      padding: 10px 16px;
      background-color: #333;
      color: #fff;
      text-decoration: none;
      border-radius: 4px;
    }

    .navbar-link:hover {
      background-color: #555;
    }
  </style>
</head>

<body>
<div>
    <a href="admin.php" class="navbar-link" data-nav-link>Home</a>
    <a href="logout.php" class="navbar-link" data-nav-link style="float: right;">Log Out</a>
</div> 
  <br>
  <br>

<h2 style="text-align: center;">Update Clinic</h2>
<form action="" method="post" style="margin: 0 auto; width: 50%;">
    <input type="hidden" name="update_id" value="<?php echo $_POST['update_id']; ?>">
    <div id="menuContainer">
        <div class="menu-input">
            <label for="clinicName">Clinic Name:</label>
            <input type="text" name="clinicName" placeholder="Enter a name" id="clinicName" required
                value="<?php echo $clinics[0]['clinicName']; ?>">
            <br>
            <label for="clinicAddress">Address:</label>
            <input type="text" name="clinicAddress" placeholder="Enter the Address" id="clinicAddress" required
                value="<?php echo $clinics[0]['clinicAddress']; ?>">
            <br>
            <div id="dataRows">
                <?php
                // Display existing clinic services
                $servicesArray = explode(', ', $clinics[0]['clinicServices']);
                foreach ($servicesArray as $service) {
                    echo '<div>';
                    echo '<label for="clinicServices">Add Services:</label>';
                    echo '<input type="text" name="clinicServices[]" placeholder="Enter a service" id="clinicServices"
                        required value="' . $service . '">';
                    echo '<input type="checkbox" name="serviceCheckbox">';
                    echo '</div>';
                }
                ?>
            </div>
            <br>
        </div>
    </div>
    <br>

    <div style="text-align: center;">
        <button type="button" onclick="removeRow()">Remove</button>
        <button type="button" onclick="addRow()">Add</button>
        <button type="submit" id="submitButton" name="submit">Update</button>
    </div>
  </form>

</body>

</html>
<?php
// Exit the script here if the user is logged in
?>
