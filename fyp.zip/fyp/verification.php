<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$digitalSignature = isset($_GET['digitalSignature']) ? $_GET['digitalSignature'] : 'Digital Signature Not Found';

function calculateHash($index, $previousHash, $timestamp, $data) {
    return hash('sha256', $index . $previousHash . $timestamp . $data);
}

function IpAddress($ipAddress) {
    return ($ipAddress);
}

function caesarCipherEncrypt($string, $shift) {
    $result = "";
    $length = strlen($string);
    for ($i = 0; $i < $length; $i++) {
        if (ctype_alpha($string[$i])) {
            $isUpperCase = ctype_upper($string[$i]);
            $asciiOffset = $isUpperCase ? 65 : 97;
            $result .= chr(fmod(((ord($string[$i]) + $shift) - $asciiOffset), 26) + $asciiOffset);
        } else {
            $result .= $string[$i];
        }
    }
    return $result;
}

function generateDigitalSignature($timestamp, $macAddress, $userInputData, $ipAddress, $securedGatewayHash) {
    return $timestamp . "," . $macAddress . "," . $userInputData . "," . $ipAddress . "," . $securedGatewayHash;
}

class Block {
    public $index;
    public $timestamp;
    public $data;
    public $previousHash;
    public $hash;

    public function __construct($index, $timestamp, $data, $previousHash) {
        $this->index = $index;
        $this->timestamp = $timestamp;
        $this->data = $data;
        $this->previousHash = $previousHash;
        $this->hash = calculateHash($index, $previousHash, $timestamp, $data);
    }
}

$components = explode(",", $digitalSignature);

$block5 = new Block(0, $components[0], $components[1], "0");
$block6 = new Block(1, $components[0], $components[2], $block5->hash);
$block7 = new Block(2, $components[0], $components[3], $block6->hash);
$serverHashes = $block5->hash . ',' . $block6->hash . ',' . $block7->hash;
$caesarShiftAmount = 3;
$securedServerHash = caesarCipherEncrypt($serverHashes, $caesarShiftAmount);
$securedGatewayHash = $components[4] . ',' . $components[5] . ',' . $components[6];

if ($securedGatewayHash == $securedServerHash) {

    $dataToInsert = $components[2];  // Extract the data to be inserted into the database

    // Now, you can insert $dataToInsert into the database
    try {
        require_once 'dbhandler.php';

        $query = "INSERT INTO patient_data (pat_data, birthdate) VALUES (?,?);";  // Replace your_table_name and column_name with actual values

        $stmt = $pdo->prepare($query);

        $stmt->execute([$dataToInsert]);

        $pdo = null;
        $stmt = null;

        echo "Data inserted successfully";
        die();

    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }

} else {
    echo "Rejected! Data has been changed";
    die();
}
?>
